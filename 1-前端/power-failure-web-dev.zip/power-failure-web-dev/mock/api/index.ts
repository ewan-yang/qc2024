import auth from './auth';
import route from './route';

export default [...auth, ...route];
