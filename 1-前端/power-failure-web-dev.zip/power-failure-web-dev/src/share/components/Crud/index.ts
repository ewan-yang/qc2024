export { default as BasicCrud } from './src/BasicCrud.vue';
export * from './types/crud';
