<template>
  <n-space :vertical="true">
    <n-divider class="!mb-0 text-14px text-[#666]">其他登录方式</n-divider>
    <div class="flex-center">
      <n-button :text="true">
        <icon-mdi-wechat class="text-22px text-[#888] hover:text-[#52BF5E]" />
      </n-button>
    </div>
  </n-space>
</template>

<script lang="ts" setup></script>

<style scoped></style>
