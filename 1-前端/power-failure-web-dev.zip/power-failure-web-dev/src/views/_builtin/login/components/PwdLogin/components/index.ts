import OtherLogin from './OtherLogin.vue';
import OtherAccount from './OtherAccount.vue';

export { OtherLogin, OtherAccount };
