import CornerTop from './CornerTop.vue';
import CornerBottom from './CornerBottom.vue';

export { CornerTop, CornerBottom };
