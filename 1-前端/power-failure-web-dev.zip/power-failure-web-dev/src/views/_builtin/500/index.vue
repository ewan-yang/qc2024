<template>
  <exception-base type="500" />
</template>

<script lang="ts" setup></script>

<style scoped></style>
