<template>
  <exception-base type="404" />
</template>

<script lang="ts" setup></script>

<style scoped></style>
