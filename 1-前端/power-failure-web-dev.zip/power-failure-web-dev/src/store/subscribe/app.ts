/** 订阅app store */
export default function subscribeAppStore() {
  //
}
