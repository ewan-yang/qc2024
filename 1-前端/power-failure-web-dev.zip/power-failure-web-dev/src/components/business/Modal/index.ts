export { default as BasicModal } from './src/BasicModal.vue';
