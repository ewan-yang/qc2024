export const FORMTYPE = {
  add: '新增',
  del: '删除',
  detail: '详情',
  edit: '编辑'
};
