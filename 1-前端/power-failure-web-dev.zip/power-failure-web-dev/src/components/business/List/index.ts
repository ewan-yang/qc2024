export { default as BasicList } from './src/BasicList.vue';
