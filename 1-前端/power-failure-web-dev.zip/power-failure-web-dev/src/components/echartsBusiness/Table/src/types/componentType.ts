import type { ComponentType as ct } from '../../../Form';

export type ComponentType = ct;
