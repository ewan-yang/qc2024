export { default as proTable } from './src/BasicTable.vue';
export { default as TableAction } from './src/components/TableAction.vue';

export * from './src/types/table';
export * from './src/types/tableAction';
