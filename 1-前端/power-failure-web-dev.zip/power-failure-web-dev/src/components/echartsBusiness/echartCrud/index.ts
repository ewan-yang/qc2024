export { default as EchartsBasicCrud } from './src/EchartsBasicCrud.vue';
export * from './types/crud';
