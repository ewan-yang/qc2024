export { default as proForm } from './src/BasicForm.vue';
export * from './src/types/form';
export * from './src/types/index';
