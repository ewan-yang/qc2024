import VerticalSider from './VerticalSider/index.vue';
import VerticalMixSider from './VerticalMixSider/index.vue';

export { VerticalSider, VerticalMixSider };
