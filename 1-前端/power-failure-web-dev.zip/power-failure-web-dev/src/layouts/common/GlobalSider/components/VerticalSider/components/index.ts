import VerticalMenu from './VerticalMenu.vue';

export { VerticalMenu };
