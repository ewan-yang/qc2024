<template>
  <dark-mode-container class="flex-center h-full">
    <span>停电计划及通知服务应用</span>
  </dark-mode-container>
</template>

<script setup lang="ts">
defineOptions({ name: 'GlobalFooter' });
</script>

<style scoped></style>
