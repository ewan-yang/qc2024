import TabDetail from './TabDetail/index.vue';
import ReloadButton from './ReloadButton/index.vue';

export { TabDetail, ReloadButton };
