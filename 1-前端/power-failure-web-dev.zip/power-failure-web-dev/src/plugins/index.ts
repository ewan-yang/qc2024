import setupAssets from './assets';
export { setupAssets };

export { setupNaive } from '@/plugins/naive';
