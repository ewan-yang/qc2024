import 'uno.css';
import 'virtual:svg-icons-register';
import '../styles/css/global.css';

/** import static assets: css, js , font and so on. - [引入静态资源，css、js和字体文件等] */
export default function setupAssets() {}
